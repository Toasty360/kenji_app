package com.example.kenji

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
